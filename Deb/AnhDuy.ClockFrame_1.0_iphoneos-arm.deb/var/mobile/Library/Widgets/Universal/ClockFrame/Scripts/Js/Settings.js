/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';
document.documentElement.style.setProperty('--br', config.br + 'px');

/* Om off */
if(!config.AmLich){
document.getElementById('Calendar').style.display = 'block';
document.getElementById('AmLich').style.display = 'none';}

if(!config.Condition){
document.getElementById('City').style.display = 'block';
document.getElementById('Condition').style.display = 'none';}

/* on off */
if(!config.WeIcon){
document.getElementById('WeIcon').style.display = 'none';}

/* Color */
document.documentElement.style.setProperty('--thuCl', config.thuCl);
document.documentElement.style.setProperty('--thoigianCl', config.thoigianCl);
document.documentElement.style.setProperty('--duonglichCl', config.duonglichCl);
document.documentElement.style.setProperty('--amlichCl', config.amlichCl);
document.documentElement.style.setProperty('--thanhphoCl', config.thanhphoCl);
document.documentElement.style.setProperty('--thoitietCl', config.thoitietCl);
document.documentElement.style.setProperty('--BgCl', config.BgCl);
document.documentElement.style.setProperty('--Bg1Cl', config.Bg1Cl);