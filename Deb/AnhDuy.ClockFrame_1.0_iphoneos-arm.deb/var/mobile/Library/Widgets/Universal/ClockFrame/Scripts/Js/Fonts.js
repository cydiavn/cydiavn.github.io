let fontFamily = new FontFace("Fontad", `url(${'/fonts/' + config.Fontad + '.ttf'}) format("truetype")`);
fontFamily.load().then(function(loadedFont){
document.fonts.add(loadedFont);})
