/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';
/* Color */
document.documentElement.style.setProperty('--thoigianCl', config.thoigianCl);
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--thoigianCl2', config.thoigianCl2);
document.documentElement.style.setProperty('--dateCl2', config.dateCl2);
/* ratio */
document.documentElement.style.setProperty('--dongho', config.dongho + '%');
document.documentElement.style.setProperty('--dongho1', config.dongho1 + '%');
document.documentElement.style.setProperty('--ngay', config.ngay + '%');
document.documentElement.style.setProperty('--dongho2', config.dongho2 + '%');
/* On off */
if(!config.gra){
document.getElementById('Clock').classList.remove('Gradient');
document.getElementById('Calendar').classList.remove('Gradient1');
}
