$('head').removeAttr('Mode');
if (config.Mode == '1') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/1.css" type="text/css" >');
}
else if (config.Mode == '2') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/2.css" type="text/css" >');
}