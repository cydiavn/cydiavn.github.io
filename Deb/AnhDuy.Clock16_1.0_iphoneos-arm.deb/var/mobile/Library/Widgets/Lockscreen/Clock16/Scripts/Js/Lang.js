if (window.config.language == "Vietnamese") {
var alText = ["âm lịch "];
var dateText = [" "];
var days =  ["Chủ Nhật,", "Thứ Hai,", "Thứ Ba,", "Thứ Tư,", "Thứ Năm,", "Thứ Sáu,", "Thứ Bảy,"]
var months = ["tháng 01", "tháng 02", "tháng 03", "tháng 04", "tháng 05", "tháng 06", "tháng 07", "tháng 08", "tháng 09", "tháng 10", "tháng 11", "tháng 12"];
var condition =  ["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Có dông", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù nhẹ", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Mưa giông vài nơi", "blank"];
} else {
var alText = ["Lunar "];
var dateText = [" "];
var days = ["Sunday,", "Monday,", "Tuesday,", "Wednesday,", "Thursday,", "Friday,", "Saturday,"];
var months =["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var condition = ["Tornado", "Tropical storm", "Hurricane", "Severe thunderstorms", "Thunderstorms", "Mixed rain and snow", "Mixed rain and sleet", "Mixed snow and sleet", "Freezing drizzle", "drizzle", "Freezing rain", "Showers", "Showers", "Snow flurries", "Light snow showers", "Blowing snow", "Snow", "Hail", "Sleet", "Dust", "Foggy", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy ", "Mostly cloudy", "Mostly cloudy", "Partly cloudy", "Partly cloudy", "Clear", "Sunny", "Fair", "Fair", "Mixed rain and hail", "Hot", "Isolated thunderstorms", "Scattered thunderstorms", "Scattered thunderstorms", "Scattered showers", "Heavy snow", "Scattered snow showers", "Heavy snow", "Partly cloudy", "Thundershowers", "Snow showers", "Isolated thundershowers", "Not available"];
}