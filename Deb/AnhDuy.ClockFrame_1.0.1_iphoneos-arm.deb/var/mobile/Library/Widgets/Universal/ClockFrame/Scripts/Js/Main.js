var iPhoneType = "auto";
if (iPhoneType == "auto") {
if (screen.height == 480) { iPhoneType = "iPh12Pro"; }
else if (screen.height == 568) { iPhoneType = "iPh5"; }
else if (screen.height == 667) { iPhoneType = "iPh678"; }
else if (screen.height == 736) { iPhoneType = "iPh678Plus"; }
else if (screen.height == 812) { iPhoneType = "iPhX"; }
else if (screen.height == 896) { iPhoneType = "iPhMax"; }
else if (screen.height == 844) { iPhoneType = "iPh12Pro"; }
else { iPhoneType = "iPh12Max"; }
}

window.addEventListener("load", function() { 
switch(iPhoneType) {

case "iPh4":
document.body.style.width='320px';
document.body.style.height='480px';
$("#Hour").css({ "font-size":"70px" ,"left":"106px", "letter-spacing":"2"});
$("#Minute").css({ "font-size":" 70px" ,"left":"218px" , "letter-spacing":"2"});
$("#City").css({ "top":" 66px", "font-size":" 14px"});
$("#Condition").css({ "top":" 66px",  "font-size":" 14px"});
$("#AmLich").css({ "top":" 161px", "font-size":" 15px"});
$("#Calendar").css({ "top":" 161px",  "font-size":" 15px"});
$("#WeIcon").css({ "top":" 116px", "width":" 72px"});
break;

case "iPh5":
document.body.style.width='320px';
document.body.style.height='568px';
$("#Hour").css({ "font-size":"80px" ,"left":"106px", "letter-spacing":"2"});
$("#Minute").css({ "font-size":" 80px" ,"left":"218px" , "letter-spacing":"2"});
$("#City").css({ "top":" 80px", "font-size":" 15px"});
$("#Condition").css({ "top":" 80px",  "font-size":" 15px"});
$("#AmLich").css({ "top":" 189px", "font-size":" 15px"});
$("#Calendar").css({ "top":" 189px",  "font-size":" 15px"});
$("#WeIcon").css({ "top":" 147px", "width":" 70px"});
break;

case "iPh678":
document.body.style.width='375px';
document.body.style.height='667px';
$("#Hour").css({ "font-size":"95px" ,"left":"123px" , "letter-spacing":"2"});
$("#Minute").css({ "font-size":" 95px" ,"left":"256px" , "letter-spacing":"2"});
$("#City").css({ "top":" 95px" , "font-size":" 17px"});
$("#Condition").css({ "top":" 95px" , "font-size":" 17px"});
$("#AmLich").css({ "top":" 220px", "font-size":" 18px"});
$("#Calendar").css({ "top":" 220px",  "font-size":" 18px"});
$("#WeIcon").css({ "top":" 173px", "width":" 80px"});
break;

case "iPh678Plus":
document.body.style.width='414px';
document.body.style.height='736px';
$("#Hour").css({ "font-size":"100px" ,"left":"136px" , "letter-spacing":"2"});
$("#Minute").css({ "font-size":" 100px" ,"left":"281px" , "letter-spacing":"2"});
$("#City").css({ "top":" 105px" , "font-size":" 18px"});
$("#Condition").css({ "top":" 105px" , "font-size":" 18px"});
$("#AmLich").css({ "top":" 244px", "font-size":" 19px"});
$("#Calendar").css({ "top":" 244px",  "font-size":" 19px"});
$("#WeIcon").css({ "top":" 189px", "width":" 89px"});
break;

case "iPhX":
document.body.style.width='375px';
document.body.style.height='812px';
$("#Hour").css({ "font-size":"115px" ,"left":"117.5px"});
$("#Minute").css({ "font-size":" 115px"});
$("#City").css({ "top":" 116px" , "font-size":" 18px"});
$("#Condition").css({ "top":" 116px" , "font-size":" 18px"});
$("#AmLich").css({ "top":" 269px", "font-size":" 19px"});
$("#Calendar").css({ "top":" 269px",  "font-size":" 19px"});
$("#WeIcon").css({ "top":" 218px", "width":" 82px"});
break;

case "iPhMax":
document.body.style.width='414px';
document.body.style.height='896px';
$("#Hour").css({ "font-size":"130px" ,"left":"130px"});
$("#Minute").css({ "font-size":" 130px"});
$("#City").css({ "top":" 130px"});
$("#Condition").css({ "top":" 130px"});
break;

case "iPh12Pro":
document.body.style.width='390px';
document.body.style.height='844px';
$("#Hour").css({ "font-size":"120px" ,"left":"122.7px"});
$("#Minute").css({ "font-size":" 120px"});
break;

case "iPh12Max":
document.body.style.width='428px';
document.body.style.height='926px';
break;
}}, false);