let fontFamily = new FontFace("FontSelect", `url(${'/fonts/' + config.fontSelect + '.ttf'}) format("truetype")`);
fontFamily.load().then(function(loadedFont){
document.fonts.add(loadedFont);})