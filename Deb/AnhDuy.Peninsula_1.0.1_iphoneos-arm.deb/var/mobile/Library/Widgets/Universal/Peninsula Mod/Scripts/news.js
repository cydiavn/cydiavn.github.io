
var xfer = {};
xfer.debug = true;
xfer.news = [];
xfer.rss = null;

var error = false;
var currPage = 1;
var maxPages, news_link;

function loadNews(url){
	xfer.rss = url;
	
	document.getElementById("new-title").innerHTML = '';
	//document.getElementById("new-au").innerHTML = '';
	//document.getElementById("new-desc").innerHTML = '';
	
	xfer.news = [];
	currPage = 1;
	
	feednami.load(url,function(result){
		if(result.error) {
			console.log(result.error);
			error = true;
			document.getElementById("_source").innerHTML = 'Error Loading News';
		} else {
			var entries = result.feed.entries;
			for(var i = 0; i < entries.length; i++){
				var entry = entries[i];
				xfer.news.push(entry);
			}
			
			document.getElementById("_source").innerHTML = result.feed.meta.title;
			maxPages = xfer.news.length;
			setTimeout(placeNews, 200);
		}
		
		//console.log('[FSXW] Loaded ' + xfer.news.length + ' news articles!');
	});
}

function placeNews(){
	
	document.getElementById("page").innerHTML = currPage;
	document.getElementById("total").innerHTML = maxPages;
	
	/*if(currPage < 2){
		document.getElementById("_pr").style.display = 'none';
	}else{
		document.getElementById("_pr").style.display = 'block';
	}
	
	if(currPage > maxPages - 1){
		document.getElementById("_ne").style.display = 'none';
	}else{
		document.getElementById("_ne").style.display = 'block';
	}*/
	
	const item = xfer.news[currPage - 1];
	
	document.getElementById("new-title").innerHTML = item.title;
	/*if(item.author !== null){
		document.getElementById("new-au").innerHTML = item.author;
	}
	document.getElementById("new-desc").innerHTML = item.summary;*/
	
	news_link = item.link;
}


function nextPage(){
	if(currPage < maxPages){
		currPage++;
		placeNews();
	}else{
		currPage = 1;
		placeNews();
	}
}

function prevPage(){
	if(currPage > 1){
		currPage--;
		placeNews();
	}else{
		currPage = maxPages;
		placeNews();
	}
}

function openSafari(url) {
    window.location = url;
}

