
Lang = config.lang;

if (Lang == "vi") {
	var greet = ["Chào buổi sáng","Chào buổi chiều","Chào buổi tối","Chúc ngủ ngon"];
    var shortdays =  ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];
    var days = ["CN", "Thứ 02", "Thứ 03", "Thứ 04", "Thứ 05", "Thứ 06", "Thứ 07"];
    var months= ["Tháng Một", "Tháng Hai", "Tháng Ba", "Tháng Tư", "Tháng Năm", "Tháng Sáu", "Tháng Bảy", "Tháng Tám", "Tháng Chín", "Tháng Mười", "Tháng Mười Một", "Tháng Mười Hai"];
    var shortmonths =["- 01", "- 02", "- 03", "- 04", "- 05", "- 06", "- 07", "- 08", "- 09", "- 10", "- 11", "- 12"];
    var hourtext = ["Mười hai giờ", "Một giờ", "Hai giờ", "Ba giờ", "Bốn giờ", "Năm giờ", "Sáu giờ", "Bảy giờ", "Tám giờ", "Chín giờ", "Mười giờ", "Mười một giờ", "Mười hai giờ", "Một giờ", "Hai giờ", "Ba giờ", "Bốn giờ", "Năm giờ", "Sáu giờ", "Bảy giờ", "Tám giờ", "Chín giờ", "Mười giờ", "Mười một giờ", "Mười hai giờ"];
    var minutestext =[" đúng", "một phút", "hai phút", "ba phút", "bốn phút", "năm phút", "sáu phút", "bảy phút", "tám phút", "chín phút", "mười", "mười một", "mười hai", "mười ba", "mười bốn", "mười lăm", "Mười sáu", "Mười bảy", "mười tám", "Mười chín", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Hai mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Ba mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Bốn mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi", "Năm mươi"];
    var minutesunittext =["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "mốt", "Hai", "Ba", "tư", "Lăm", "Sáu", "Bảy", "Tám", "Chín", "", "mốt", "Hai", "Ba", "tư", "Năm", "Sáu", "Bảy", "Tám", "Chín", "", "mốt", "Hai", "Ba", "tư", "Lăm", "Sáu", "Bảy", "Tám", "Chín", "", "mốt", "Hai", "Ba", "tư", "Lăm", "Sáu", "Bảy", "Tám", "Chín", ""];
    var weatherdesc =["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Giông bão", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù nhẹ", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Mưa giông vài nơi", "blank"];
}

if (Lang == "en") {
	var greet = ["Good Morning","Good Afternoon","Good Evening","Good Night"];
    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var shortdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
    var shortmonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var hourtext = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
    var minutestext = ["O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", ""];
    var minutesunittext = ["clock", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""];
    var weatherdesc = ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"];
} 



