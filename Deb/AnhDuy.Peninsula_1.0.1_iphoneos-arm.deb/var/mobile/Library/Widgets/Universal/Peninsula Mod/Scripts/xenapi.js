
var bt = 0;
var isCharging = false;

function mainUpdate(type){ 
	if (type == "statusbar" && config.st){
		sigBars(document.getElementById("wl2"),parseInt(wifiBars), 3);
		sigBars(document.getElementById("sl2"),parseInt(signalBars), 4);
	}
}

function sigBars(indicator,_curr, _max){
	indicator.style.width = _curr * 20 / _max + 'px';
}



function XenApi(){
	
	api.weather.observeData(function (newData) {
		checkWeather(newData);
	});
	
	api.media.observeData(function (newData) {
		appPlaying = newData.nowPlayingApplication.identifier;
		checkMusic(newData);
	});
	
	api.comms.observeData(function (newData) {
		checkComms(newData);
	});
	
	api.resources.observeData(function (newData) {
		checkBattery(newData);
	});
	
}

function checkWeather(newData){
	
	document.getElementById('cond').innerHTML = weatherdesc[newData.now.condition.code];
	document.getElementById('temp').innerHTML = newData.now.temperature.current;
	document.getElementById('weIcon').src = 'weather/' + newData.now.condition.code + '.png';
	
	document.getElementById('sun-text').innerHTML = newData.now.sun.sunset.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
	document.getElementById('rise-text').innerHTML = newData.now.sun.sunrise.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
	
	
}


//------------------------- BATTERY FUNCTIONS ---------------------------
function checkBattery(newData){
	
	document.getElementById('perc').innerHTML = newData.battery.percentage;
	
	if(newData.battery.percentage <= 50){
		document.getElementById('battC').className = 'progress-circle p' + newData.battery.percentage;
	}else{
		document.getElementById('battC').className = 'progress-circle over50 p' + newData.battery.percentage;
	}
	
	if(newData.battery.state === 1){
		if(!isCharging){
			isCharging = true;
			document.getElementById('device').src = 'img/device.svg';
			document.getElementById('perc-d').innerHTML = newData.battery.percentage;
			if(newData.battery.percentage <= 50){
				document.getElementById('battC-d').className = 'progress-circle p' + newData.battery.percentage;
			}else{
				document.getElementById('battC-d').className = 'progress-circle over50 p' + newData.battery.percentage;
			}
			openConn('conn');
			setTimeout(()=>{
				closeConn('conn');
			}, 2000);
		}
	}else{
		isCharging = false;
	}
}

function checkComms(newData){
	if (newData.bluetooth.devices.length !== bt && newData.bluetooth.devices.length > 0) {
		bt = newData.bluetooth.devices.length;
		let i = bt - 1;
		
		document.getElementById('perc-d').innerHTML = newData.bluetooth.devices[i].supportsBattery ? newData.bluetooth.devices[i].battery : 'N/A';
		
		if(newData.bluetooth.devices[i].supportsBattery){
			if(newData.bluetooth.devices[i].battery <= 50){
				document.getElementById('battC-d').className = 'progress-circle p' + newData.bluetooth.devices[i].battery;
			}else{
				document.getElementById('battC-d').className = 'progress-circle over50 p' + newData.bluetooth.devices[i].battery;
			}
		}
		
		if(newData.bluetooth.devices[i].majorClass === 1024){
			document.getElementById('device').src = 'img/headphones.svg';
		}else if(newData.bluetooth.devices[i].majorClass === 1792){
			document.getElementById('device').src = 'img/watch.svg';
		}else{
			document.getElementById('device').src = 'img/bluetooth.svg';
		}
		
		openConn('conn');
		setTimeout(()=>{
			closeConn('conn');
		}, 2000);
	}else{
		bt = 0;
	}
}

function openConn(el){
			if(!document.getElementById('music-big').classList.contains('closed')){
				move('music-big');
			}
			openToSmall('bg');
			open(el);
			show(el);
			if(config.st)
				hide('stbar');
}

function closeConn(el){
			closeToSmall('bg');
			close(el);
			hide(el);
			if(config.st)
				show('stbar');
}








