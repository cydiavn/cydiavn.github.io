
var appPlaying;//, timer = null, isScroll = false;

//var C1P = '#EA3B5A', C2P = '#1CF1F2', C3P = '#E243B7', C4P = '#CEDFEB', C5P = '#3A97FE';
//var sc = 'date-container';
//var an = true, pn = 100;

var mi = 15, re; 
var rssfeed = 'https://news.google.com/rss';

function init(){
	
	//showSmallMusic(true);
	//move('conn');
	checkSettings();
	loadNews(rssfeed);
	
	updateClock();
	setInterval("updateClock();", 1000);
	
	XenApi();
	
}

function move(el){
	if(document.getElementById(el).classList.contains('closed')){
		
		if(el === 'weather-big' || el === 'music-big' || el === 'news'){
			document.getElementById(el).classList.remove('closed');
			document.getElementById(el).classList.add('open');
			show(el);
			bounce('bg');
			if(config.st)
				hide('stbar');
			
			if(el === 'music-big'){
				document.getElementById('music').style.zIndex = 10;
				document.getElementById('music-small').classList.add('big');
				open('art-s-cont')
				if(!document.getElementById('weather').classList.contains('closed')){
					//move('weather');
					//document.getElementById('music').style.zIndex = 10;
					document.getElementById('weather-small').classList.add('small');
					close('weather-big');
					hide('weather-big');
					
					if(document.getElementById('weather-small').classList.contains('small')){
						//document.getElementById('weather-small').style.top = '160px';
						document.getElementById('weather-small').classList.remove('move');
					}
				}
				
				if(!document.getElementById('news').classList.contains('closed')){
					move('news');
				}
			}
			
			if(el === 'weather-big'){
				document.getElementById('weather').style.zIndex = 10;
				document.getElementById('music').style.zIndex = 0;
				document.getElementById('news').style.zIndex = 0;
				open('weather');
				show('weather');
				open('weather-small');
				show('weather-small');
			}
			
			if(el === 'news'){
				document.getElementById(el).style.zIndex = 10;
				if(document.getElementById('weather-small').classList.contains('open')){
					close('weather');
					hide('weather');
					close('weather-small');
					hide('weather-small');
					document.getElementById('weather-small').classList.remove('small');
					document.getElementById('weather-small').classList.remove('move');
				}
			}
		}
		
		/*if(el === 'conn'){
			if(!document.getElementById('music-big').classList.contains('closed')){
				move('music-big');
			}
			openToSmall('bg');
			open(el);
			show(el);
			if(config.st)
				hide('stbar');
		}*/
		
	}else{
		
		if(el === 'weather-big' || el === 'music-big' || el === 'news'){
			document.getElementById(el).classList.add('closed');
			document.getElementById(el).classList.remove('open');
			document.getElementById(el).style.zIndex = 0;
			hide(el);
			removeBounce('bg');
			if(config.st)
				show('stbar');
			
			if(el === 'music-big'){
				document.getElementById('music-small').classList.remove('big');
				close('art-s-cont');
				
				if(document.getElementById('weather-small').classList.contains('small')){
					document.getElementById('weather-small').classList.remove('small');
					document.getElementById('weather-small').classList.add('move');
				}
			}
			
			if(el === 'weather-big'){
				close('weather');
				hide('weather');
				close('weather-small');
				hide('weather-small');
			}
		}
		
		if(el === 'weather-small'){
			document.getElementById('weather').style.zIndex = 10;
			document.getElementById('music').style.zIndex = 0;
			document.getElementById('news').style.zIndex = 0;
			open('weather');
			show('weather');
			open('weather-big');
			show('weather-big');
			if(document.getElementById('music-big').classList.contains('open')){
			   move('music-big');
			}
			bounce('bg');
			document.getElementById('weather-small').classList.remove('small');
			document.getElementById('weather-small').classList.remove('move');
		}
		
		/*if(el === 'conn'){
			closeToSmall('bg');
			close(el);
			hide(el);
			if(config.st)
				show('stbar');
		}*/
	}
}

function openToSmall(el){
	document.getElementById(el).classList.add('small');
	open('center');
}

function closeToSmall(el){
	document.getElementById(el).classList.remove('small');
	close('center');
}

function show(el){
	document.getElementById(el).style.display = 'block';
	setTimeout(()=>{
		document.getElementById(el).classList.add('show');
		document.getElementById(el).classList.remove('hide');
	}, 100);
}

function hide(el){
	document.getElementById(el).classList.remove('show');
	document.getElementById(el).classList.add('hide');
	setTimeout(()=>{
		document.getElementById(el).style.display = 'none';
	}, 400);
}

function open(el){
	//open('center');
	document.getElementById(el).classList.remove('closed');
	document.getElementById(el).classList.add('open');
}

function close(el){
	document.getElementById(el).classList.add('closed');
	document.getElementById(el).classList.remove('open');
	//close('center');
}

function bounce(el){
	open(el);
	setTimeout(()=>{
		document.getElementById(el).classList.add('bounce1');
		setTimeout(()=>{
			document.getElementById(el).classList.add('bounce2');
			document.getElementById('center').classList.add('shadow-dark-out');
		},150);
	},150);
}

function removeBounce(el){
	document.getElementById('center').classList.remove('shadow-dark-out');
	document.getElementById(el).classList.remove('bounce2');
	setTimeout(()=>{
		document.getElementById(el).classList.remove('bounce1');
		setTimeout(()=>{
			close(el);
		},150);
	},150);
}




function openApp(app){
	api.apps.launchApplication(app);
}



