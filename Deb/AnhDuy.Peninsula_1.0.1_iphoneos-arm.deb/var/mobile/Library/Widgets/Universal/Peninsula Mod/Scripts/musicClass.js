
//------------------------- MUSIC FUNCTIONS ---------------------------
var volume;
var anim = false, isPlaying = false;

function checkMusic(newData){
	
	volume = newData.volume;
	
    if (newData.isPlaying) {
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
		
		if(document.getElementById('visCont').classList.contains('off')){
			anim = true;
			visAnim();
		}
    } else {
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
		
		anim = false;
		visAnim();
    }
	
	if (newData.isStopped) {
		isPlaying = false;
		setTimeout(()=>{
			if(!isPlaying)
				showSmallMusic(false);
		},1000);
		document.getElementById('title').innerHTML = 'No Media';
		document.getElementById('artist').innerHTML = '';
		document.getElementById('title').classList.remove("marquee");
		
		anim = false;
		visAnim();
	}else{
		isPlaying = true;
		setTimeout(()=>{
			if(isPlaying)
				showSmallMusic(true);
		},1000);
		//addOpen('music-container');
		document.getElementById('title').innerHTML = newData.nowPlaying.title;
		document.getElementById('artist').innerHTML = newData.nowPlaying.artist;
		
		if (checkOverflow(document.getElementById('title')) === true){
			document.getElementById('title').classList.add("marquee");
		} else {
			document.getElementById('title').classList.remove("marquee");
		}
		
	}
	
	// Artwork image
	//document.getElementById('musicArt').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'img/note.PNG';
	document.getElementById('musicArt-small').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'img/note.PNG';
	
	
}

function playPause() {
	document.getElementById('playPause').style.opacity = 0.5;
	setTimeout(function (){
		document.getElementById('playPause').style.opacity = 1;
	}, 200);
	api.media.togglePlayPause();
	
}


function next() {
	document.getElementById('next').style.opacity = 0.5;
	setTimeout(function (){
		document.getElementById('next').style.opacity = 1;
	}, 200);
	api.media.nextTrack();
}
			
function prev() {
	document.getElementById('prev').style.opacity = 0.5;
	setTimeout(function (){
		document.getElementById('prev').style.opacity = 1;
	}, 200);
	api.media.previousTrack();
}

function setVolume(vol){
	if(vol === 'in'){
		if(volume < 100){
			volume += 5;
			api.media.setVolume(volume);
		}
	}else{
		if(volume > 0){
			volume -= 5;
			api.media.setVolume(volume);
		}
	}
}


function handleTrackTimes(elapsed, length, forceUpdate) {

    const elapsedContent = length === 0 ? '--:--' : secondsToFormatted(elapsed);
    document.getElementById('elapsed').innerHTML = elapsedContent;

    const lengthContent = length === 0 ? '--:--' : secondsToFormatted(length);
    document.getElementById('length').innerHTML = lengthContent;

	document.getElementById('barIn').style.width = elapsed * 100 / length + '%';
	
}

function secondsToFormatted(seconds) {
    if (seconds === 0) return '00:00';

    const isNegative = seconds < 0;
    if (isNegative) return '00:00';

    seconds = Math.abs(seconds);
    const hours = Math.floor(seconds / 60 / 60);
    const minutes = Math.floor(seconds / 60) - (hours * 60);
    const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));

    if (hours > 0) {
        return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    } else {
        return (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    }
}


function checkOverflow(el) {
	var curOverflow = el.style.overflow;
	if ( !curOverflow || curOverflow === "visible" ){
		el.style.overflow = "hidden"; 
	}
	var isOverflowing = el.clientWidth < el.scrollWidth;// || el.clientHeight < el.scrollHeight
	el.style.overflow = curOverflow;
	return isOverflowing; 
} 

function visAnim(){
	if(anim){
		document.getElementById('vl1').style.height = '50%';
		document.getElementById('vl2').style.height = '50%';
		document.getElementById('vl3').style.height = '50%';
		setTimeout(function (){
			document.getElementById('vl1').style.height = '20%';
			document.getElementById('vl2').style.height = '10%';
			document.getElementById('vl3').style.height = '20%';
		}, 400);
		setTimeout(function (){
			document.getElementById('vl1').style.height = '40%';
			document.getElementById('vl2').style.height = '30%';
			document.getElementById('vl3').style.height = '40%';
		}, 800);
		setTimeout(function (){
			document.getElementById('vl1').style.height = '20%';
			document.getElementById('vl2').style.height = '5%';
			document.getElementById('vl3').style.height = '10%';
		}, 1200);
		setTimeout(function (){
			visAnim(anim);
		}, 1600);
	}else{
		document.getElementById('vl1').style.height = '10%';
		document.getElementById('vl2').style.height = '10%';
		document.getElementById('vl3').style.height = '10%';
	}
}



function showSmallMusic(sh){
	if(sh){
		if(config.st)
			hide('stbar');
		
		open('music');
		show('music');
		setTimeout(()=>{
			openToSmall('bg');
			show('music-small');
			
			setTimeout(()=>{
				closeToSmall('bg');
				open('music-small');
				document.getElementById('art-s-cont').classList.add('small');
				if(config.st)
					show('stbar');
			}, 2000);
		},300);
	}else{
		if(!document.getElementById('music-big').classList.contains('closed')){
			move('music-big');
		}
		
		if(config.st)
			show('stbar');
		
		setTimeout(()=>{
			openToSmall('bg');
			close('music-small');
			setTimeout(()=>{
				closeToSmall('bg');
				close('music');
				hide('music');
				document.getElementById('art-s-cont').classList.remove('small');
				document.getElementById('music-small').classList.add('closed');
				document.getElementById('music-small').classList.remove('open');
			},500)
		},300);
	}
}


