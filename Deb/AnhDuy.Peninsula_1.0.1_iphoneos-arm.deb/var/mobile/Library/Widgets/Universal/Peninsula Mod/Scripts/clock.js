
//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	var th, pm = '';
	
	if(config.Time24){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	if (Clock === "12h"){
		if( currentHours >= 12 ){
			pm = 'pm';
		}else{
			pm = 'am';
		}
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentHours = ( currentHours< 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		//currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	
	//getGreet(currentTime.getHours(), 'greet');
	
	document.getElementById("time").innerHTML = currentHours + ':' + currentMinutes1 + pm;
	
	document.getElementById("date").innerHTML = shortdays[currentTime.getDay()] + ' ' + currentDate + ' ' + shortmonths[currentTime.getMonth()];
	
		
}

function getGreet(hour, elem){
	if(hour >= 6 && hour < 12){
		document.getElementById(elem).innerHTML = greet[0];
	}
	if(hour >= 12 && hour <= 17){
		document.getElementById(elem).innerHTML = greet[1];
	}
	if(hour > 17 && hour <= 21){
		document.getElementById(elem).innerHTML = greet[2];
	}
	if(hour === 22){
		document.getElementById(elem).innerHTML = greet[3];
	}
	if(hour >= 23 || hour < 6){
		document.getElementById(elem).innerHTML = "Zzzz";
	}
}


var sdays = ["S", "M", "T", "W", "T", "F", "S"];
function addWeekdays(container){
	for(var i=0; i<shortdays.length; i++){
		var dayCont = document.createElement('div');
		dayCont.className = 'weekdayCont';
		if(i === 0 || i === shortdays.length - 1){
			dayCont.classList.add('we');
		}
		dayCont.innerHTML = shortdays[i];
		dayCont.id = 'day' + i;
		
		document.getElementById(container).appendChild(dayCont);
	}
}
