

//var isTop = false;

//var pa = 1;

function checkSettings(){
	
	rssfeed = config.rssfeed;
	
document.documentElement.style.setProperty("--textColor", config.textColor);
document.documentElement.style.setProperty("--textColor1", config.textColor1);
document.documentElement.style.setProperty("--textColor2", config.textColor2);
document.documentElement.style.setProperty("--textColor3", config.textColor3);
document.documentElement.style.setProperty("--textColor4", config.textColor4);
document.documentElement.style.setProperty("--textColor5", config.textColor5);
document.documentElement.style.setProperty("--textColor6", config.textColor6);
document.documentElement.style.setProperty("--nutColor", config.nutColor);
document.documentElement.style.setProperty("--khungColor", config.khungColor);

document.documentElement.style.setProperty('--br', config.br + 'px');
	document.documentElement.style.setProperty('--nW', config.nW + 'px');
	
	if(!config.st){
		document.getElementById('time').style.display = 'none';
		document.getElementById('battery-container').style.display = 'none';
		document.getElementById('wifiCont').style.display = 'none';
		document.getElementById('signalCont').style.display = 'none';
	}
	
}

