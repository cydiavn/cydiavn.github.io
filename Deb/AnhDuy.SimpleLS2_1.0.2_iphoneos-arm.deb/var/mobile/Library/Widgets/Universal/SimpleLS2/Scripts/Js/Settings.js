/* Scale */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';
/* Color */
document.documentElement.style.setProperty('--thoigianCl', config.thoigianCl);
document.documentElement.style.setProperty('--duonglichCl', config.duonglichCl);
document.documentElement.style.setProperty('--amlichCl', config.amlichCl);
document.documentElement.style.setProperty('--thanhphoCl', config.thanhphoCl);
document.documentElement.style.setProperty('--thoitietCl', config.thoitietCl);