function mainUpdate(type){ 
if (type === "weather"){checkWeather();} 
function checkWeather(){
document.getElementById("Condition").innerHTML = condition[weather.conditionCode];
document.getElementById("City").innerHTML = weather.city.substring(0,24);
document.getElementById("Temp").innerHTML = weather.temperature + '&deg;';
document.getElementById('WeIcon').src = 'Scripts/Weather/' + config.IconSet + '/' + weather.conditionCode + '.png';
}}