/* Scale, radius & blur */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Color */
document.documentElement.style.setProperty('--dateCl', config.dateCl);
document.documentElement.style.setProperty('--weekCl', config.weekCl);
document.documentElement.style.setProperty('--StrokeCl', config.StrokeCl);
document.documentElement.style.setProperty('--clockCl', config.clockCl);
