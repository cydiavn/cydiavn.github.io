
let bp;

function XenApi(){
	
	if(config.mu){
		api.media.observeData(function (newData) {
			appPlaying = newData.nowPlayingApplication.identifier;
			checkMusic(newData);
		});

		api.media.observeElapsedTime(function (newElapsedTime) {
			handleTrackTimes(newElapsedTime, api.media.nowPlaying.length, false);
		});
	}
	
	if(config.he){
		api.weather.observeData(function (newData) {
			checkWeather(newData);
		});

		api.resources.observeData(function (newData) {
			checkBattery(newData);
		});
	}
	
}

function checkWeather(newData){
	
	document.getElementById('cond').innerHTML = weatherdesc[newData.now.condition.code];
	document.getElementById('temp').innerHTML = newData.metadata.address.city + ', ' + newData.now.temperature.current + 'º - ' + bp + '%';
	
	var icon, i;
    for (i = 0; i < 2; i++) {
		document.getElementById('hour-im' + i).src = 'weather/' + newData.hourly[i].condition.code + '.png';
		document.getElementById('time' + i).innerHTML = newData.hourly[i].timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + '<br><span>' +
			newData.hourly[i].temperature.feelsLike + 'º</span>';
    }
	
}

function forecast(){
	for(var i=0; i<2; i++){
		let hour = document.createElement('div'),
			imh = document.createElement('img'),
			time = document.createElement('div');
		
		hour.classList.add('fore-cont');
		
		imh.classList.add('icon');
		imh.src = 'weather/' + i + '.png';
		imh.id = 'hour-im' + i;
		hour.appendChild(imh);
		
		time.classList.add('txt');
		time.id = 'time' + i;
		time.innerHTML = 'time<br>12º';
		hour.appendChild(time);
		
		document.getElementById("forecast-hour").appendChild(hour);
	}
}


//------------------------- BATTERY FUNCTIONS ---------------------------
function checkBattery(newData){
	
	bp = newData.battery.percentage;
}








