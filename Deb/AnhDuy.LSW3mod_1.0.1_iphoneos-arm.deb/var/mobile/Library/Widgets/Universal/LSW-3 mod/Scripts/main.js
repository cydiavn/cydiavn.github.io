
var appPlaying;//, timer = null, isScroll = false;

//var C1P = '#EA3B5A', C2P = '#1CF1F2', C3P = '#E243B7', C4P = '#CEDFEB', C5P = '#3A97FE';
//var sc = 'date-container';
//var an = true, pn = 100;

var mi = 15, re; 
var rssfeed = 'https://news.google.com/rss';

function init(){
	//showSmallMusic(true);
	//move('conn');
	/*
	loadNews(rssfeed);*/
	checkSettings();
	
	if(config.he){
		updateClock();
		setInterval("updateClock();", 1000);
		forecast();
	}
	
	XenApi();
	
}


function show(el){
	document.getElementById(el).style.display = 'block';
	setTimeout(()=>{
		document.getElementById(el).classList.add('open');
		document.getElementById(el).classList.remove('close');
	}, 100);
}

function hide(el){
	document.getElementById(el).classList.remove('open');
	document.getElementById(el).classList.add('close');
	setTimeout(()=>{
		document.getElementById(el).style.display = 'none';
	}, 400);
}

function open(el){
	//open('center');
	document.getElementById(el).classList.remove('hide');
	document.getElementById(el).classList.add('show');
}

function close(el){
	document.getElementById(el).classList.add('hide');
	document.getElementById(el).classList.remove('show');
	//close('center');
}

function move(el){
	if(document.getElementById(el).classList.contains('hide')){
		open(el);
		
		if(el === 'musicArt-cont'){
			open('info-cont');
			show('back-container');
			open('head-container');
		}
		
		if(el === 'weather-container'){
			show(el);
			if(!document.getElementById('musicArt-cont').classList.contains('hide')){
				close('musicArt-cont');
				close('info-cont');
				hide('back-container');
				close('head-container');
			}
			
			if(!document.getElementById('music-container').classList.contains('close')){
				hide('music-container');
			}
			
			if(isPlaying){
				show('head-music');
				document.getElementById('head-container').classList.remove("music");
			}
		}
	}else{
		close(el);
		
		if(el === 'musicArt-cont'){
			close('info-cont');
			hide('back-container');
			close('head-container');
		}
		
		if(el === 'weather-container'){
			hide(el);
		}
	}
}

function moveMusic(){
	document.getElementById('head-container').classList.add("music");
	show('music-container');
	if(!document.getElementById('weather-container').classList.contains('hide')){
		hide('weather-container');
	}
	hide('head-music');
}




function openApp(app){
	api.apps.launchApplication(app);
}



