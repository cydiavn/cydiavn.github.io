
//------------------------- MUSIC FUNCTIONS ---------------------------
var volume;
var anim = false, isPlaying = false;

function checkMusic(newData){
	
	volume = newData.volume;
	
    if (newData.isPlaying) {
		document.getElementById('play').style.display = 'none';
		document.getElementById('pause').style.display = 'block';
		
		/*if(document.getElementById('visCont').classList.contains('off')){
			anim = true;
			visAnim();
		}*/
    } else {
		document.getElementById('play').style.display = 'block';
		document.getElementById('pause').style.display = 'none';
		
		//anim = false;
		//visAnim();
    }
	
	if (newData.isStopped) {
		isPlaying = false;
		document.getElementById('title').innerHTML = 'không phát';
		document.getElementById('artist').innerHTML = '';
		document.getElementById('album').innerHTML = '';
		document.getElementById('head-music').innerHTML = '';
		document.getElementById('title').classList.remove("marquee");
		hide('head-music');
		hide('music-container');
		if(!document.getElementById('musicArt-cont').classList.contains('hide')){
			close('musicArt-cont');
			close('info-cont');
			hide('back-container');
			close('head-container');
		}
		document.getElementById('head-container').classList.remove("music");
		//anim = false;
		//visAnim();
	}else{
		isPlaying = true;
		if(config.he)
			document.getElementById('head-container').classList.add("music");
		
		show('music-container');
		if(!document.getElementById('weather-container').classList.contains('hide')){
			hide('weather-container');
		}
		
		document.getElementById('title').innerHTML = newData.nowPlaying.title;
		document.getElementById('head-music').innerHTML = '<span style="color:var(--secondary);">Đang phát :</span> ' + newData.nowPlaying.title;
		document.getElementById('artist').innerHTML = newData.nowPlaying.artist;
		document.getElementById('album').innerHTML = newData.nowPlaying.album;
		
		if (checkOverflow(document.getElementById('title')) === true){
			document.getElementById('title').classList.add("marquee");
		} else {
			document.getElementById('title').classList.remove("marquee");
		}
		
	}
	
	// Artwork image
	document.getElementById('musicArt').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'img/note.PNG';
	document.getElementById('musicArt-bg').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'img/note.PNG';
	
	
}

function playPause(el) {
	document.getElementById(el).style.opacity = 0.5;
	setTimeout(function (){
		document.getElementById(el).style.opacity = 1;
	}, 200);
	api.media.togglePlayPause();
	
}


function next() {
	document.getElementById('next').style.opacity = 0.5;
	setTimeout(function (){
		document.getElementById('next').style.opacity = 1;
	}, 200);
	api.media.nextTrack();
}
			
function prev() {
	document.getElementById('prev').style.opacity = 0.5;
	setTimeout(function (){
		document.getElementById('prev').style.opacity = 1;
	}, 200);
	api.media.previousTrack();
}

function setVolume(vol){
	if(vol === 'in'){
		if(volume < 100){
			volume += 5;
			api.media.setVolume(volume);
		}
	}else{
		if(volume > 0){
			volume -= 5;
			api.media.setVolume(volume);
		}
	}
}


function handleTrackTimes(elapsed, length, forceUpdate) {

    const elapsedContent = length === 0 ? '--:--' : secondsToFormatted(elapsed);
    document.getElementById('elapsed').innerHTML = elapsedContent;

    const lengthContent = length === 0 ? '--:--' : secondsToFormatted(length);
    document.getElementById('length').innerHTML = lengthContent;

	document.getElementById('barIn').style.width = elapsed * 100 / length + '%';
	
}

function secondsToFormatted(seconds) {
    if (seconds === 0) return '00:00';

    const isNegative = seconds < 0;
    if (isNegative) return '00:00';

    seconds = Math.abs(seconds);
    const hours = Math.floor(seconds / 60 / 60);
    const minutes = Math.floor(seconds / 60) - (hours * 60);
    const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));

    if (hours > 0) {
        return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    } else {
        return (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    }
}


function checkOverflow(el) {
	var curOverflow = el.style.overflow;
	if ( !curOverflow || curOverflow === "visible" ){
		el.style.overflow = "hidden"; 
	}
	var isOverflowing = el.clientWidth < el.scrollWidth;// || el.clientHeight < el.scrollHeight
	el.style.overflow = curOverflow;
	return isOverflowing; 
} 



