

var isLight = false;

function checkSettings(){
	
	switch (config.mo) {
		case 1:
			setDark();
			break;
		case 2:
			setLight();
			break;
		case 3:
			var x = window.matchMedia("(prefers-color-scheme: dark)");
			var y = window.matchMedia("(prefers-color-scheme: light)");
			dark(x); 
			x.addListener(dark);
			light(y); 
			y.addListener(light);
			break;
	}
	
	if(!config.he){
		document.getElementById('head-container').style.display = 'none';
	}else{
		document.documentElement.style.setProperty('--fontC', config.fontC);
		
		document.documentElement.style.setProperty('--wY', config.wY + 'px');
		
		document.documentElement.style.setProperty('--hY', config.hY + 'px');
		document.documentElement.style.setProperty('--hYo', config.hYo + '%');
		document.documentElement.style.setProperty('--hYm', config.hYm + 'px');
		
		document.documentElement.style.setProperty('--sF', config.sF + 'rem');
		document.documentElement.style.setProperty('--bF', config.bF + 'rem');
	}
	
	if(!config.mu){
		document.getElementById('music-container').style.display = 'none';
	}else{
		document.documentElement.style.setProperty('--mY', config.mY + 'px');
	}
	
	document.documentElement.style.setProperty('--br', config.br + 'px');
	document.documentElement.style.setProperty('--bl', config.bl + 'px');
	
	/*rssfeed = config.rssfeed;
	
	document.documentElement.style.setProperty('--secondary', config.C2);
	
	document.documentElement.style.setProperty('--br', config.br + 'px');
	document.documentElement.style.setProperty('--nW', config.nW + 'px');
	
	if(!config.st){
		document.getElementById('time').style.display = 'none';
		document.getElementById('battery-container').style.display = 'none';
		document.getElementById('wifiCont').style.display = 'none';
		document.getElementById('signalCont').style.display = 'none';
	}*/
	
}


function dark(x) {
  if (x.matches) { 
	setDark();
  }
}

function light(y) {
  if (y.matches) {
	setLight();
  }
}

function setDark(){
	isLight = false;
	
	document.documentElement.style.setProperty('--primary', '#DADADA');
	document.documentElement.style.setProperty('--secondary', config.C2);
	
	document.documentElement.style.setProperty('--trC', 'rgba(0,0,0,.3)');
	
	var ic = document.getElementsByClassName('icon');
	for(var i = 0; i < ic.length; i++) {
		ic[i].classList.remove('invertColor');
	}
	
	
}

function setLight(){
  	isLight = true;
	
	document.documentElement.style.setProperty('--primary', '#000000');
	document.documentElement.style.setProperty('--secondary', config.lC2);
	
	document.documentElement.style.setProperty('--trC', 'rgba(255,255,255,.4)');
	
	var ic = document.getElementsByClassName('icon');
	for(var i = 0; i < ic.length; i++) {
		ic[i].classList.add('invertColor');
	}
	
}

