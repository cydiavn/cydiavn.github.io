/* Scale, radius & blur */
document.body.style.webkitTransform = 'scale(' + config.Scale + ')';

/* Om off */
if(!config.AmLich){
document.getElementById('DateMonth').style.display = 'block';
document.getElementById('AmLich').style.display = 'none';}
if(!config.Clock){
document.getElementById('Temp').style.display = 'block';
document.getElementById('Clock').style.display = 'none';}

/* Color */
document.documentElement.style.setProperty('--dlCl', config.dlCl);
document.documentElement.style.setProperty('--alCl', config.alCl);
document.documentElement.style.setProperty('--thuCl', config.thuCl);
document.documentElement.style.setProperty('--StrokeCl', config.StrokeCl);
document.documentElement.style.setProperty('--ndCl', config.ndCl);
document.documentElement.style.setProperty('--tgCl', config.tgCl);
